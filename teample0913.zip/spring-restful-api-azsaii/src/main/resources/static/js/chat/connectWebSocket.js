let sock = new SockJS("/ws/chat");  // 웹소켓 연결 요청
let ws = Stomp.over(sock);
let reconnect = 0;

// vue.js
let vm = new Vue({
    el: '#app',
    data: {
        roomId: '',       // 채팅방 고유 id
        room: {},         // roomId로 채팅방 조회해서 가져온 채팅방 정보
        senderName: '',   // 메시지 발신자 이름
        senderId: '',     // 메시지 발신자 id
        message: '',      // 메시지 내용
        messages: [],      // 메시지 객체 저장 배열
    },
    created() {
        this.roomId = localStorage.getItem('wschat.roomId');
        this.senderId = localStorage.getItem('wschat.loginMemberId');     // 로그인한 사용자의 id
        this.senderName = localStorage.getItem('wschat.loginMemberName');     // 발신자(로그인한 사용자) 이름
        this.findRoom();

        // 채팅 구독
        this.connectChat = this.connectChat.bind(this);
        this.connectChat();

        // 페이지가 포커스될 때 readMessage 함수 실행
        window.addEventListener('focus', () => {
            setTimeout(() => {
                this.readMessage();
            }, 100);
        });

        // 페이지 변화 감지하여 readMessage 함수 실행
        const observer = new MutationObserver(() => {
            setTimeout(() => {
                this.readMessage();
            }, 100);
        });
        observer.observe(document, { childList:true, subtree:true });
    },
    watch: {
        // 화면 변경 시 스크롤을 최하단으로 옮긴다.
        messages: function() {
            this.scrollToBottom();
        }
    },
    methods: {
        findRoom: function() {
            // roomId로 조회 후 채팅방 정보를 가져온다.
            axios.get('/chat/room/' + this.roomId).then(response => { this.room = response.data; });

            // roomId로 채팅방 메시지 정보를 가져온다.
            // 채팅방에 메시지가 없으면 response.data가 null이기 때문에 null이 아닐 때만 this.messages에 저장한다.
            axios.get('/chat/messages/' + this.roomId).then(response => {this.messages = response.data ? response.data : [];});
        },
        connectChat: function() {
            // pub/sub event
            ws.connect({},
                (frame) => {
                    // 채팅방 구독
                    ws.subscribe("/sub/chat/room/" + this.roomId, (message) => {
                        let recv = JSON.parse(message.body);
                        this.recvMessage(recv);
                    });
                }, (error) => {
                    if(reconnect++ <= 5) {
                        setTimeout(function() {
                            console.log("connection reconnect");
                            sock = new SockJS("/ws/chat");
                            ws = Stomp.over(sock);
                            this.connectChat();
                        },10*1000);
                    }
                });
        },
        // 메시지 전송
        sendMessage: function() {
            if (this.message.trim() === '') // 아무것도 입력되지 않았으면 전송하지 않는다.
                return;

            ws.send("/pub/chat/message", {}, JSON.stringify({
                messageId: 0,
                roomId: this.roomId,
                senderName: this.senderName,
                senderId: this.senderId,
                message: this.message,
                type: 'TALK',
                checked: 'false'
            }));
            this.message = '';
        },
        // 받은 메시지를 messages 배열에 추가
        recvMessage: function(recv) {
            console.log(Array.isArray(this.messages));  // true 를 출력해야 정상
            this.messages.push({
                "messageId":recv.messageId,
                "roomId":recv.roomId,
                "senderName":recv.senderName,
                "senderId":recv.senderId,
                "message":recv.message,
                "type":recv.type,
                "checked": recv.checked
            });
        },
        // 나와 상대방 대화 내용에 서로 다른 스타일 적용을 위한 함수
        isMyChat(message) {
            return this.senderId == message.senderId;
        },
        isOtherChat(message) {
            return this.senderId != message.senderId;
        },
        // 새로운 채팅이 발생하면 스크롤을 최하단으로 옮기는 함수
        scrollToBottom: function () {
            this.$nextTick(function () {
                var listGroup = this.$refs.listGroup;
                listGroup.scrollTop = listGroup.scrollHeight;
            });
        },
        readMessage: function() {
            console.log("readMessage!!");
            ws.send("/pub/chat/read", {}, JSON.stringify({
                messageId: 0,
                roomId: this.roomId,
                senderName: this.senderName,
                senderId: this.senderId,
                message: '',
                type: 'ENTER',
                checked: true
            }));
        },
    }
});