package com.teample.packages.chat.controller;

import com.teample.packages.chat.domain.ChatRoomDTO;
import com.teample.packages.chat.service.ChatMessageService;
import com.teample.packages.chat.domain.ChatMessageDTO;
import com.teample.packages.chat.service.ChatRoomService;
import com.teample.packages.member.domain.Member;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Log4j2
public class ChatMessageController {

    private final SimpMessageSendingOperations sendingOperations; //특정 Broker로 메세지를 전달. SimpMessagingTemplate 와 같음.
    private final ChatMessageService chatMessageService;
    private final ChatRoomService chatRoomService;

    /**
     * 채팅방에서 메시지를 전송하면 이곳으로 매핑된다.
     * Config에서 설정한 applicationDestinationPrefixes, @MessageMapping 경로가 병합
     * /pub/chat/message로 메시지를 보내면 이쪽으로 온다.
     */
    @MessageMapping("/chat/message")
    public void send(ChatMessageDTO message) {
        // 메시지 저장
        chatMessageService.createMessage(message);

        // 채팅방으로 메시지 다시 publish
        // /sub/chat/room/ 구독자에게 보낸다.
        sendingOperations.convertAndSend("/sub/chat/room/" + message.getRoomId(), message);

        // 상대방에게 내가 채팅을 보냈음을 알리는 메시지를 보낸다.
        // 이 메시지로 인해 상대의 읽지 않은 메시지 수가 하나 더해진다.
        String[] temp = message.getRoomId().split("-");
        String targetId = "";
        for(String s : temp){
            if(!s.equals(message.getSenderId().toString())) {
                targetId = s;
            }
        }

        sendingOperations.convertAndSend("/sub/notification/" + targetId, message);
    }

    /**
     * 내가 채팅방에 있으면 상대방의 메시지를 읽음 처리
     */
    @MessageMapping("/chat/read")
    public void read(ChatMessageDTO message) {
        // 읽지 않은 메시지를 읽음 처리, 읽은 메시지 수 반환해서 message 내용으로 설정
        int readCount = chatMessageService.turnCheckedTrue(message);
        message.setMessage(String.valueOf(readCount));

        // 읽은 메시지의 수를 전송
        // 이 메시지는 나에게만 전송되어 알림에 사용된다.
        sendingOperations.convertAndSend("/sub/checked/" + message.getSenderId(), message);
    }

    /**
     * 로그인하면 채팅방 별로 읽지 않은 메시지 수를 전송한다.
     * uncheckedMessageList 는 채팅방 별로 읽지 않은 메시지의 수를 내용으로 담고 있는 데이터다.
     */
    @MessageMapping("/chat/enter")
    public void enter(@SessionAttribute(name = "loginMember", required = true) Member loginMember) {
        List<ChatRoomDTO> chatRoomDTOList = chatRoomService.getRoomsByUserId(loginMember.getId().toString());
        List<ChatMessageDTO> uncheckedMessageList = chatMessageService.getUnchecked(chatRoomDTOList, loginMember.getId());
        sendingOperations.convertAndSend("/sub/getUnchecked/" + loginMember.getId(), uncheckedMessageList);
    }

    /**
     * 채팅방 입장 시 메시지들 반환
     */
    @GetMapping("/chat/messages/{roomId}")
    @ResponseBody
    public List<ChatMessageDTO> getMessages(@PathVariable String roomId) {
        return chatMessageService.getMessagesByRoomId(roomId);
    }
}


