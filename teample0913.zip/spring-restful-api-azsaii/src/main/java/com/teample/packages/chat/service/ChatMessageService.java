package com.teample.packages.chat.service;


import com.teample.packages.chat.domain.ChatMessageDTO;
import com.teample.packages.chat.domain.ChatRoomDTO;
import com.teample.packages.chat.repository.ChatMessageRepository;
import com.teample.packages.chat.repository.MemoryChatMessageRepository;
import com.teample.packages.member.domain.Member;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Log4j2
public class ChatMessageService {

    private final ChatMessageRepository chatMessageRepository;

    /**
     * 메시지를 db에 저장
     */
    public void createMessage(ChatMessageDTO message) {
        chatMessageRepository.saveMessage(message);
    }

    /**
     * 채팅방 id로 메시지 객체들을 조회
     */
    public List<ChatMessageDTO> getMessagesByRoomId(String roomId) {
        return chatMessageRepository.findByRoomId(roomId);
    }

    /**
     * 채팅방 입장 시 내가 읽지 않은 메시지들을 읽음 처리한다.
     */
    public int turnCheckedTrue(ChatMessageDTO chatMessageDTO) {
        int count = 0;
        List<ChatMessageDTO> messages = chatMessageRepository.findByRoomId(chatMessageDTO.getRoomId());
        if(messages == null) return count;  // 채팅 데이터가 없으면 0 반환

        for(ChatMessageDTO c : messages) {
            // 상대방이 보낸 메시지가 읽지 않은 상태일 때 읽음으로 전환
            if(!c.getSenderId().equals(chatMessageDTO.getSenderId()) && c.getChecked() == false) {
                c.setChecked(true);
                count++;
            }
        }

        return count;
    }

    /**
     * 읽지 않은 메시지 수 반환
     */
    public List<ChatMessageDTO> getUnchecked(List<ChatRoomDTO> chatRoomDTOList, Long senderId) {
        return chatMessageRepository.countUnchecked(chatRoomDTOList, senderId);
    }

    /**
     * 메시지 삭제
     */
    public void deleteMessage(ChatMessageDTO chatMessageDTO) {
        chatMessageRepository.delete(chatMessageDTO);
    }
}
