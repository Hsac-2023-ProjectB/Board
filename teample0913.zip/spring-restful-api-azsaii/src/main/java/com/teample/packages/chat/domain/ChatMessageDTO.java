package com.teample.packages.chat.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class ChatMessageDTO {

        public enum MessageType {
                TALK, ENTER;
        }

        // 메시지 ID
        private String messageId;

        // 채팅방 ID
        private String roomId;

        // 송신자 이름
        private String senderName;

        // 송신자 id
        private Long senderId;

        //내용
        private String message;

        //메시지 타입
        private MessageType type;

        // 읽음 확인
        private Boolean checked;
}
