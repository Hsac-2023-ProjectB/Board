package com.teample.packages.chat.repository;

import com.teample.packages.chat.domain.ChatRoomDTO;

import java.util.List;

public interface ChatRoomRepository {

    ChatRoomDTO saveRoom(ChatRoomDTO ChatRoomDTO);
    ChatRoomDTO findByRoomId(String roomId);

    List<ChatRoomDTO> findByUserId(String userId);

    void delete(String roomId);
}
