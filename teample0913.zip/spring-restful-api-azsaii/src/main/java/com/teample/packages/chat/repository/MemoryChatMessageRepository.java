package com.teample.packages.chat.repository;

import com.teample.packages.chat.domain.ChatMessageDTO;
import com.teample.packages.chat.domain.ChatRoomDTO;

import java.util.*;

public class MemoryChatMessageRepository implements ChatMessageRepository{

    // 순서대로 메시지를 저장하기 위해 LinkedHashMap 사용
    private static final LinkedHashMap<String, List<ChatMessageDTO>> store = new LinkedHashMap<>();
    private static long sequence = 0L;

    @Override
    public ChatMessageDTO saveMessage(ChatMessageDTO chatMessageDTO) {
        String id = chatMessageDTO.getRoomId() + chatMessageDTO.getSenderId() + ++sequence;
        chatMessageDTO.setMessageId(id);

        if(store.get(chatMessageDTO.getRoomId()) != null) {
            List<ChatMessageDTO> list = store.get(chatMessageDTO.getRoomId());
            list.add(chatMessageDTO);
        }
        else {
            List<ChatMessageDTO> list = new ArrayList<>();
            list.add(chatMessageDTO);
            store.put(chatMessageDTO.getRoomId(), list);
        }

        return chatMessageDTO;
    }

    /**
     * 채팅방 id로 메시지 객체들을 조회
     */
    @Override
    public List<ChatMessageDTO> findByRoomId(String roomId) {
        return store.get(roomId);
    }

    /**
     * 채팅방 별로 내가 보낸 메시지가 아닌 것 중 읽지 않은 메시지의 수를 반환한다.
     */
    @Override
    public List<ChatMessageDTO> countUnchecked(List<ChatRoomDTO> chatRoomDTOList, Long senderId) {
        if(store.values() == null) return null;

        List<ChatMessageDTO> result = new ArrayList<>();
        for(ChatRoomDTO room : chatRoomDTOList) {
            int cnt = 0;
            ChatMessageDTO countMessage = new ChatMessageDTO();
            List<ChatMessageDTO> msgList = store.get(room.getRoomId());
            if(msgList == null) continue;
            for(ChatMessageDTO msg : msgList) {
                // 내가 참여중인 채팅방에서, 상대방이 보낸 메시지 중, 확인 안한것
                if(msg.getRoomId().contains(senderId.toString())
                        && !msg.getSenderId().equals(senderId.toString()) && msg.getChecked() == false) {
                    cnt++;
                }
            }
            countMessage.setRoomId(room.getRoomId());
            countMessage.setMessage(Integer.toString(cnt));
            result.add(countMessage);
        }

        return result;
    }

    /**
     * 메시지 삭제
     */
    @Override
    public void delete(ChatMessageDTO chatMessageDTO) {

        List<ChatMessageDTO> list = store.get(chatMessageDTO.getRoomId());
        list.remove(chatMessageDTO);
    }
}
