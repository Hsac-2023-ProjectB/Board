package com.teample;

import com.teample.packages.chat.repository.ChatMessageRepository;
import com.teample.packages.chat.repository.ChatRoomRepository;
import com.teample.packages.chat.repository.MemoryChatMessageRepository;
import com.teample.packages.chat.repository.MemoryChatRoomRepository;
import com.teample.packages.member.repository.*;
import com.teample.packages.member.service.MemberService;
import com.teample.packages.profile.repository.MemoryProfileRepository;
import com.teample.packages.profile.repository.ProfileRepository;
import com.teample.packages.profile.service.ProfileService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

    @Bean
    public MemberRepository memberRepository() { //memberRepository 빈 등록
        return new MemoryMemberRepository();
    }

    @Bean
    public ProfileRepository profileRepository() { //profileRepository 빈 등록
        return new MemoryProfileRepository();
    }

    @Bean
    public ChatMessageRepository chatMessageRepository() {
        return new MemoryChatMessageRepository();
    }

    @Bean
    public ChatRoomRepository chatRoomRepository() {
        return new MemoryChatRoomRepository();
    }

}