package com.sumproj.board.domain.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name="board")
public class BoardEntity extends TimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String writer;
    private String title;
    private String content;
    private String member;
    private String field;
    private int view;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;

    @Builder
    public BoardEntity(Long id, String title, String content, String writer, String member, String field, int view, LocalDateTime createdDate, LocalDateTime modifiedDate){
        this.id=id;
        this.writer=writer;
        this.title=title;
        this.content=content;
        this.field = field;
        this.member=member;
        this.view=view;
        this.createdDate=createdDate;
        this.modifiedDate=modifiedDate;
    }

    public void increaseViewCnt() {
        this.view++;
    }
    public String[] getSplitFields() {
        return (field != null && !field.trim().isEmpty()) ? field.split(",") : new String[0];
    }
}
