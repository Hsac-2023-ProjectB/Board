package com.sumproj.board.dto;

import com.sumproj.board.domain.entity.BoardEntity;
import lombok.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class BoardDto {
    private Long id;
    private String writer;
    private String title;
    private String content;
    private String member;
    private List<String> availableFields;
    private List<String> selectedFields;
    private Category field;
    private int view;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    public enum Category {
        IT,HUMANITIES,SOCIAL_SCIENCES,OTHER
    }
    private BoardDto convertEntityToDto(BoardEntity boardEntity) {
        BoardDtoBuilder builder = BoardDto.builder()
                .id(boardEntity.getId())
                .title(boardEntity.getTitle())
                .content(boardEntity.getContent())
                .writer(boardEntity.getWriter())
                .selectedFields(Arrays.asList(boardEntity.getSplitFields()))
                .member(boardEntity.getMember())
                .view(boardEntity.getView())
                .createdDate(boardEntity.getCreatedDate());

        return builder.build();
    }
    public BoardEntity toEntity(){
        BoardEntity boardEntity = BoardEntity.builder()
                .id(id)
                .writer(writer)
                .title(title)
                .content(content)
                .member(member)
                .view(view)
                .field(field != null ? field.toString() : null)
                .build();

        return boardEntity;
    }

    @Builder
    public BoardDto(Long id, String title, String content, String writer, String member, Category field, int view, LocalDateTime createdDate, LocalDateTime modifiedDate, List<String> selectedFields){
        this.id = id;
        this.writer = writer;
        this.title = title;
        this.content = content;
        this.selectedFields = selectedFields;
        this.member = member;
        this.view = view;
        this.createdDate = createdDate;
        this.modifiedDate = modifiedDate;
        this.field = field;
    }
}