package com.sumproj.board.controller;

import com.sumproj.board.dto.BoardDto;
import com.sumproj.board.service.BoardService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
//import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
@Controller
@AllArgsConstructor
public class BoardController {
    private BoardService boardService;

    @GetMapping("/")
    public String list(Model model, @RequestParam(value = "page", defaultValue = "1") Integer pageNum) {
        List<BoardDto> boardList = boardService.getBoardlist(pageNum);
        Integer[] pageList = boardService.getPageList(pageNum);

        model.addAttribute("boardList", boardList);
        model.addAttribute("pageList", pageList);

        return "board/list.html";
    }

    @GetMapping("/post")
    public String write(Model model) {
        BoardDto boardDto = new BoardDto();
        boardDto.setAvailableFields(Arrays.asList("IT", "인문", "사회과학", "기타"));
        model.addAttribute("boardDto", boardDto);
        return "board/write.html";
    }

    @PostMapping("/post")
    public String write(BoardDto boardDto, HttpServletRequest request) {
        boardDto.setSelectedFields(Arrays.asList(request.getParameterValues("selectedFields")));
        boardService.savePost(boardDto);
        return "redirect:/";
    }


    @GetMapping("/post/{no}")
    public String detail(@PathVariable("no") Long no, Model model) throws Exception {
        BoardDto boardDTO = boardService.getPost(no);

        model.addAttribute("boardDto", boardDTO);
        return "board/detail.html";
    }

    @GetMapping("/post/edit/{no}")
    public String edit(@PathVariable("no") Long no, Model model) throws Exception {
        BoardDto boardDTO = boardService.getPost(no);

        model.addAttribute("boardDto", boardDTO);
        return "board/update.html";
    }

    @PutMapping("/post/edit/{no}")
    public String update(BoardDto boardDTO) {
        String selectedFieldsString = String.join(",", boardDTO.getSelectedFields());
        boardDTO.setField(BoardDto.Category.valueOf(selectedFieldsString));
        boardService.savePost(boardDTO);
        return "redirect:/";
    }

    @DeleteMapping("/post/{no}")
    public String delete(@PathVariable("no") Long no) {
        boardService.deletePost(no);

        return "redirect:/";
    }

    @GetMapping("/board/search")
    public String search(@RequestParam(value = "keyword") String keyword, Model model) {
        List<BoardDto> boardDtoList = boardService.searchPosts(keyword);

        model.addAttribute("boardList", boardDtoList);

        return "board/list.html";
    }
}