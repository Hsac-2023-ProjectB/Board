package com.sumproj.board.controller;

import com.sumproj.board.dto.BoardDto;
import com.sumproj.board.service.BoardService;
import lombok.AllArgsConstructor;
import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
//import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//import static sun.awt.SunGraphicsCallback.log;
//import static sun.net.www.http.KeepAliveCache.result;

@Controller
@AllArgsConstructor
public class BoardController {
    private BoardService boardService;

    /* 게시글 목록 */
    @GetMapping("/")
    public String list(Model model, @RequestParam(value = "page", defaultValue = "1") Integer pageNum) {
        List<BoardDto> boardList = boardService.getBoardlist(pageNum);
        Integer[] pageList = boardService.getPageList(pageNum);

        model.addAttribute("boardList", boardList);
        model.addAttribute("pageList", pageList);

        return "board/list.html";
    }

    /* 게시글 작성 페이지 */
    @GetMapping("/post")
    public String list() {
        return "board/write.html";
    }

    /* 게시글 작성 처리 */
    @PostMapping("/post")
    public String write(BoardDto boardDto) {
        boardService.savePost(boardDto);

        return "redirect:/";
    }

    /* 게시글 상세 페이지 */
    @GetMapping("/post/{no}")
    public String detail(@PathVariable("no") Long no, Model model) throws Exception {
        BoardDto boardDTO = boardService.getPost(no);

        model.addAttribute("boardDto", boardDTO);
        return "board/detail.html";
    }

    /* 게시글 수정 페이지*/
    @GetMapping("/post/edit/{no}")
    public String edit(@PathVariable("no") Long no, Model model) throws Exception {
        BoardDto boardDTO = boardService.getPost(no);

        model.addAttribute("boardDto", boardDTO);
        return "board/update.html";
    }

    /*게시물 수정 페이지_ 작성자 본인만 수정 가능 (@AuthenticationPrincipal 어노테이션 사용에 있어 코드 수정 중입니다.)
    @GetMapping("/post/edit/{no}")
    public String edit(@PathVariable("no") Long no, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        BoardDto boardDTO = boardService.getPost(no);

        // 작성자와 현재 사용자가 같은 경우에만 수정 가능하도록 처리
        if (boardDTO.getWriter().equals(userDetails.getUsername())) {
            model.addAttribute("boardDto", boardDTO);
            return "board/update.html";
        } else {
            return "redirect:/"; // 권한이 없는 경우 메인 페이지로 리다이렉트
        }
    }*/

    /* 게시글 수정 처리*/
    @PutMapping("/post/edit/{no}")
    public String update(BoardDto boardDTO) {
        boardService.savePost(boardDTO);

        return "redirect:/";
    }

    /*
    @PutMapping("/post/edit/{no}")
    public String update(BoardDto boardDTO, @AuthenticationPrincipal UserDetails userDetails) {
        // 작성자와 현재 사용자가 같은 경우에만 수정 가능하도록 처리
        if (boardService.isWriter(boardDTO.getPostId(), userDetails.getUsername())) {
            boardService.savePost(boardDTO);
        }

        return "redirect:/";
    }*/

    /* 게시글 삭제 처리 */
    @DeleteMapping("/post/{no}")
    public String delete(@PathVariable("no") Long no) {
        boardService.deletePost(no);

        return "redirect:/";
    }

    /*
    @DeleteMapping("/post/{no}")
    public String delete(@PathVariable("no") Long no, @AuthenticationPrincipal UserDetails userDetails) {
        BoardDto boardDto = boardService.getPost(no);

        // 작성자와 현재 사용자가 같은 경우에만 삭제 가능하도록 처리
        if (boardDto.getWriter().equals(userDetails.getUsername())) {
            boardService.deletePost(no);
        }

        return "redirect:/";
    }*/

    /* 게시글 검색 */
    @GetMapping("/board/search")
    public String search(@RequestParam(value = "keyword") String keyword, Model model) {
        List<BoardDto> boardDtoList = boardService.searchPosts(keyword);

        model.addAttribute("boardList", boardDtoList);

        return "board/list.html";
    }
}