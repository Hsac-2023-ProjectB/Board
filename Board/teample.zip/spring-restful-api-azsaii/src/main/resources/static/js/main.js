
let toggleButton = document.querySelector(".dropdown-toggle-btn");


toggleButton.addEventListener("click", function() {
    
    document.querySelector(".dropdown-menu").classList.toggle("show");
})