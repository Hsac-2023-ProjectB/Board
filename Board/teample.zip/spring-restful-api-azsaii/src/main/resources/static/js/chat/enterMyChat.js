let sock = new SockJS("/ws/chat");  // 웹소켓 연결 요청
let ws = Stomp.over(sock);
let reconnect = 0;

let loginMemberId;              // 로그인 사용자 id
let loginMemberName;            // 로그인 사용자 이름
let profileId = 0         // getLoginInfo()에서 필요. 마이페이지는 pageId 없음

let vm = new Vue({
    el: '#app',
    data: {
        chatrooms : [],         // 내가 참여 중인 채팅방 정보
        uncheckedMessageCounts : {},  // { roomId1: count1, roomId2: count2, ... }
        uncheckedMessages : localStorage.getItem('uncheckedMessages') ? JSON.parse(localStorage.getItem('uncheckedMessages')) : [],
    },
    created() {
        this.setMyChatRoom();

        // 로컬 스토리지 변경 감지 및 처리
        window.addEventListener('storage', (event) => this.handleLocalStorageChange(event));
        for (const msg of this.uncheckedMessages) {
            this.uncheckedMessageCounts[msg.roomId] = msg.message;
        }
    },
    methods: {
        // 마이페이지에서 내가 참여중인 채팅방들 검색해서 chatrooms 로 가져온다.
        setMyChatRoom: async function() {
            axios.get(`/chat/rooms`).then(response => {
                this.chatrooms = response.data;
            });

            // 로그인 정보를 전역변수에 가져온다.
            await this.getLoginInfo();
        },
        // 채팅 참여자들의 회원 정보 요청해서 가져오는 함수
        // async - await 사용: get 요청으로 정보를 가져오기 전에 채팅방이 생성되는 것을 막기 위해 동기 처리 필요
        getLoginInfo: async function() {
            await axios.get('/chat/info/' + profileId)
                .then(response => {
                    loginMemberId = response.data.loginMember.id;
                    loginMemberName = response.data.loginMember.name;
                }).catch(error => {
                    console.error('getLoginInfo Error:', error); // 에러가 발생하면 콘솔에 오류 출력
                });
        },
        // 채팅방 입장
        enterRoom: function(item) {
            console.log("enterRoom!");

            // 채팅방에 필요한 정보 넘겨주기
            localStorage.setItem('wschat.roomId', item.roomId);
            localStorage.setItem('wschat.loginMemberId', loginMemberId);
            localStorage.setItem('wschat.loginMemberName', loginMemberName);

            // 채팅방을 팝업창으로 열기
            let url = "/chat/room/enter";
            let name = "_blank";
            let option = "width = 500, height = 800, top = 100, left = 200, location = no"
            window.open(url, name, option);
        },
        // 로컬스토리지에 저장된 안읽은 메시지가 변하면 감지해서 업데이트한다.
        handleLocalStorageChange(event) {
            if (event.key === 'uncheckedMessages') {
                console.log("update!");
                const newValue = event.newValue;
                this.uncheckedMessages = newValue ? JSON.parse(newValue) : [];

                for (const msg of this.uncheckedMessages) {
                    this.$set(this.uncheckedMessageCounts, msg.roomId, msg.message);
                    console.log("TEST: " + this.uncheckedMessageCounts[msg.roomId]);
                }
            }
        }
    }
});