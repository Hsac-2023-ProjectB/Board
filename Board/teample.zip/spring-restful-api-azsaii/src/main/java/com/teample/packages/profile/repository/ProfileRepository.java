package com.teample.packages.profile.repository;

import com.teample.packages.profile.domain.Profile;

import java.util.List;

public interface ProfileRepository {

    Profile save(Profile profile);
    Profile findById(Long id);

    List<Profile> findAllByAuthorId(Long authorId);

    List<Profile> findAll();

    void update(Long updateProfileId, Profile updateParam);

    void delete(Long profileId);

    Long findAuthorIdByProfileId(Long profileId);
}
