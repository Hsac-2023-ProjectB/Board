package com.teample.packages.chat.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class ChatRoomDTO {

    private String roomId;
    private String roomName;
    private String submembers;
}