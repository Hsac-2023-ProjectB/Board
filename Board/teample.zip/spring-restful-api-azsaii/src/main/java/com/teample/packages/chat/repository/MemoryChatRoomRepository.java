package com.teample.packages.chat.repository;

import com.teample.packages.chat.domain.ChatRoomDTO;

import java.util.*;

public class MemoryChatRoomRepository implements ChatRoomRepository{

    // 순서대로 채팅방을 저장하기 위해 LinkedHashMap 사용
    private static final LinkedHashMap<String, ChatRoomDTO> store = new LinkedHashMap<>();

    /**
     * 채팅방을 db에 저장
     */
    @Override
    public ChatRoomDTO saveRoom(ChatRoomDTO chatRoomDTO) {
        store.put(chatRoomDTO.getRoomId(), chatRoomDTO);

        return chatRoomDTO;
    }

    /**
     * 채팅방 id로 조회
     */
    @Override
    public ChatRoomDTO findByRoomId(String roomId) {

        for(ChatRoomDTO c : store.values()) {
            if(c.getRoomId().equals(roomId))
                return c;
        }

        return null;
    }

    /**
     * 채팅방 삭제
     */
    @Override
    public void delete(String roomId) {
        if(store.get(roomId) != null)
            store.remove(roomId);
    }

    /**
     * 사용자 id로 채팅방 불러오기
     */
    @Override
    public List<ChatRoomDTO> findByUserId(String userId) {
        List<ChatRoomDTO> result = new ArrayList<>();

        for (ChatRoomDTO c : store.values()) {
            if (c.getRoomId().contains(userId)) {
                result.add(c);
            }
        }

        if (result.size() == 0) return null;
        else return result;
    }
}
