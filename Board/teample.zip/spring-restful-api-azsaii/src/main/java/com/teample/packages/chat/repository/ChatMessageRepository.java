package com.teample.packages.chat.repository;

import com.teample.packages.chat.domain.ChatMessageDTO;
import com.teample.packages.chat.domain.ChatRoomDTO;

import java.util.List;

public interface ChatMessageRepository {

    ChatMessageDTO saveMessage(ChatMessageDTO chatMessageDTO);
    List<ChatMessageDTO> findByRoomId(String roomId);
    List<ChatMessageDTO> countUnchecked(List<ChatRoomDTO> chatRoomDTOList, Long senderId);
    void delete(ChatMessageDTO chatMessageDTO);
}
