package com.teample.packages.chat.service;

import com.teample.packages.chat.domain.ChatRoomDTO;
import com.teample.packages.chat.repository.ChatRoomRepository;
import com.teample.packages.member.domain.Member;
import com.teample.packages.member.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * db 연결 후 repository 생성해서 기능 이전 필요
 */
@Service
@RequiredArgsConstructor
@Log4j2
public class ChatRoomService {

    private final MemberService memberService;      // 멤버 정보 검색을 위해 사용
    private final ChatRoomRepository chatRoomRepository;

    // 로그
    public static final Logger logger = LogManager.getLogger(ChatRoomService.class);

    /**
     * 채팅방을 db에 저장
     */
    public ChatRoomDTO createRoom(ChatRoomDTO chatRoomDTO) {
        return chatRoomRepository.saveRoom(chatRoomDTO);
    }

    /**
     * 사용자 id로 채팅방 조회
     */
    public List<ChatRoomDTO> getRoomsByUserId(String userId) {
        return chatRoomRepository.findByUserId(userId);
    }

    /**
     * 채팅방 id로 조회
     */
    public ChatRoomDTO getRoomByRoomId(String roomId) {
        return chatRoomRepository.findByRoomId(roomId);
    }

    /**
     * 채팅방 삭제
     */
    public void deleteChatRoom(String roomId) {
        chatRoomRepository.delete(roomId);
    }

    /** 채팅 상대방 정보 조회 및 반환
     */
    public Member setChatTargetInfo(Long targetId) {
        Member targetMember = memberService.findMemberById(targetId);
        return targetMember;
    }
}
